import org.junit.jupiter.api.Assertions.*
#parse("File Header.java")
class ${NAME} {
  ${BODY}
}