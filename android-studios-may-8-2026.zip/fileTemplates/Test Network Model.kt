#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end

import com.greengagemobile.util.parseJsonString
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

#parse("File Header.java")
class ${NAME} {
    @Test
    fun `has correct json property mapping`() {
        val expected = ${NETWORK_MODEL}()
        
        val actual = parseJsonString<${NETWORK_MODEL}>("""
            {
              //TODO: Json Response 
            }
            """
        )
        
        assertThat(actual).isEqualTo(expected)
    } 
}