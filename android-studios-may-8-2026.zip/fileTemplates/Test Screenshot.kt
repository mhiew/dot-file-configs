#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.greengagemobile.BaseScreenshotTest
import org.junit.Test
import org.junit.runner.RunWith

#parse("File Header.java")
@RunWith(AndroidJUnit4::class)
class ${NAME} : BaseScreenshotTest() {
    @Test
    fun test() {
        val viewModel = ${VIEW_MODEL}(
            //TODO: initialize view model
        )

        val view = ${VIEW}(context)
        view.accept(viewModel)

        compareScreenshot(view)
    }
}