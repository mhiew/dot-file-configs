#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end

import com.greengagemobile.common.recyclerview.DiffRowItem

#parse("File Header.java")
data class ${NAME}(
        val id: Long
) : DiffRowItem {

    //region DiffRowItem
    override fun getRowItemType(): Int = ITEM_TYPE

    override fun areItemsTheSame(o: Any?): Boolean = if (o is ${NAME}) o.id == this.id else false

    override fun areContentsTheSame(o: Any?): Boolean = if (o is ${NAME}) o == this else false
    //endregion

    companion object {
        const val ITEM_TYPE: Int = $ITEM_TYPE_INT
        //TODO: convenience static factory methods
    }
}