#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greengagemobile.common.recyclerview.RowDelegate

#parse("File Header.java")
class ${VIEW}RowDelegate(
        itemType: Int = ${VIEWMODEL}.ITEM_TYPE,
) : RowDelegate<${VIEWMODEL}, ${VIEW}Holder>(itemType) {

    override fun createViewHolder(parent: ViewGroup): ${VIEW}Holder {
        val view = ${VIEW}(parent.context)
        return ${VIEW}Holder(view)
    }

    override fun bindView(viewHolder: ${VIEW}Holder, rowItem: ${VIEWMODEL}) {
        viewHolder.bind(rowItem)
    }
}

class ${VIEW}Holder(
        view: ${VIEW},
) : RecyclerView.ViewHolder(view) {
    fun bind(viewModel: ${VIEWMODEL}) {
        val view = itemView
        if (view is ${VIEW}) {
            view.accept(viewModel)
        }
    }
}