#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end

import android.content.Context
import android.util.AttributeSet
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import androidx.constraintlayout.widget.ConstraintLayout
import com.greengagemobile.R
import com.greengagemobile.nudgetheme.ThemeColor
import io.reactivex.functions.Consumer

#parse("File Header.java")
class ${NAME} @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
) : ConstraintLayout(context, attrs), Consumer<${VIEWMODEL}> {
    //TODO store references to lateinit UI Components
    
    var observer: Observer? = null

    init {
        layoutParams = LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        inflate(context, R.layout.${LAYOUT_FILE_NAME}, this)
        initComponents()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        initComponents()
    }

    private fun initComponents() {
        setBackgroundColor(ThemeColor.WHITE)
        //TODO setup UI components
    }

    override fun accept(viewModel: ${VIEWMODEL}) {
        //TODO update UI components
    }

    interface Observer {
        //TODO
    }
}
