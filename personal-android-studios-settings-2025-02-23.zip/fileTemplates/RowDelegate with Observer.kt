#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
#end

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.greengagemobile.common.recyclerview.RowDelegate

#parse("File Header.java")
class ${VIEW}RowDelegate(
        itemType: Int = ${VIEWMODEL}.ITEM_TYPE,
        private val observer: Observer
) : RowDelegate<${VIEWMODEL}, ${VIEW}Holder>(itemType) {

    override fun createViewHolder(parent: ViewGroup): ${VIEW}Holder {
        val view = ${VIEW}(parent.context)
        return ${VIEW}Holder(view, observer)
    }

    override fun bindView(viewHolder: ${VIEW}Holder, rowItem: ${VIEWMODEL}) {
        viewHolder.bind(rowItem)
    }

    interface Observer {
        //TODO
    }
}

class ${VIEW}Holder(
        view: ${VIEW},
        observer: ${VIEW}RowDelegate.Observer
) : RecyclerView.ViewHolder(view) {
    private var viewModel: ${VIEWMODEL}? = null

    init {
        //TODO Setup View Observer
    }

    fun bind(viewModel: ${VIEWMODEL}) {
        this.viewModel = viewModel
        
        val view = itemView
        if (view is ${VIEW}) {
            view.accept(viewModel)
        }
    }
}